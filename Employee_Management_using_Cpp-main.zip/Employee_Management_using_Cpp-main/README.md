# Employee_Management_using_Cpp
This a mini project of C++ using concept of FileHandling,Vectors,Structures
In this System Details of Employee like Employee ID , Employee Name, Salary, PF fund , Health insurance and net amount is stored,additionally Total expenditure is also displayed
You have 6 options
1. Add Employee
2. Print Employee Report
3. Search Employee
4. Delete Employee"
5. Save
6. Exit
Make sure to save any changes made to system by inputing Option 5.
![1](https://user-images.githubusercontent.com/54236934/123082468-acf81d80-d43c-11eb-9ddc-07895428a910.PNG)
![2](https://user-images.githubusercontent.com/54236934/123082488-b2556800-d43c-11eb-8ffd-844491b271d1.PNG)
![3](https://user-images.githubusercontent.com/54236934/123082490-b3869500-d43c-11eb-9ce3-f7824323312d.PNG)
![4](https://user-images.githubusercontent.com/54236934/123082492-b3869500-d43c-11eb-8413-11cdaf0dc2e4.PNG)
